package com.myfirstapp.i_heart_world;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IHeartWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(IHeartWorldApplication.class, args);
	}

}
